var searchData=
[
  ['path',['path',['../structt__file.html#abcbb76676901e234c6bb3522e65f40ad',1,'t_file']]],
  ['pfile',['pFile',['../structt__file.html#ab38e5871e5240ecc10d96031f2c720cd',1,'t_file']]]
];
