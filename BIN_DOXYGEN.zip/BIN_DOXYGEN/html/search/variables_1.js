var searchData=
[
  ['coeff',['coeff',['../structt__file__unit.html#a24fd66b90744df8e551cfd4d169f965a',1,'t_file_unit']]],
  ['content',['content',['../structt__file.html#a2efccd17bb4c915b4216c2654078c25d',1,'t_file']]]
];
