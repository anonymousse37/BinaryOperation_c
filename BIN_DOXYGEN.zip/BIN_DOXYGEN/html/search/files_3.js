var searchData=
[
  ['logger_2ec',['logger.c',['../logger_8c.html',1,'']]],
  ['logger_2eh',['logger.h',['../logger_8h.html',1,'']]]
];
