var searchData=
[
  ['binw_5fsz',['BINW_SZ',['../bin_8h.html#a15e74a462a8d667569461556e9a83797',1,'bin.h']]]
];
