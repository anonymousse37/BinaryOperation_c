var searchData=
[
  ['logger',['logger',['../logger_8h.html#ae4ddb6424cb1a9269552e521edb44479',1,'logger.h']]]
];
