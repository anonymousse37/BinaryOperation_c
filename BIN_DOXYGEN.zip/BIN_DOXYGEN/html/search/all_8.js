var searchData=
[
  ['ld_5f1d_5fvalue_5finsert',['ld_1D_value_insert',['../ptrop_8c.html#a0455ed74478760a6952aed7e2454c241',1,'ld_1D_value_insert(long double **t, unsigned long long int *t_length, unsigned long long int offset, long double value):&#160;ptrop.c'],['../ptrop_8h.html#a0455ed74478760a6952aed7e2454c241',1,'ld_1D_value_insert(long double **t, unsigned long long int *t_length, unsigned long long int offset, long double value):&#160;ptrop.c']]],
  ['li_5f1d_5fvalue_5finsert',['li_1D_value_insert',['../ptrop_8c.html#a1d211118e617c2a1eec235e79601f617',1,'li_1D_value_insert(long int **t, unsigned long long int *t_length, unsigned long long int offset, long int value):&#160;ptrop.c'],['../ptrop_8h.html#a1d211118e617c2a1eec235e79601f617',1,'li_1D_value_insert(long int **t, unsigned long long int *t_length, unsigned long long int offset, long int value):&#160;ptrop.c']]],
  ['lli_5f1d_5fvalue_5finsert',['lli_1D_value_insert',['../ptrop_8c.html#a90e208a6b9b05baef4a777fc3fa82791',1,'lli_1D_value_insert(long long int **t, unsigned long long int *t_length, unsigned long long int offset, long long int value):&#160;ptrop.c'],['../ptrop_8h.html#a90e208a6b9b05baef4a777fc3fa82791',1,'lli_1D_value_insert(long long int **t, unsigned long long int *t_length, unsigned long long int offset, long long int value):&#160;ptrop.c']]],
  ['logger',['logger',['../logger_8h.html#ae4ddb6424cb1a9269552e521edb44479',1,'logger.h']]],
  ['logger_2ec',['logger.c',['../logger_8c.html',1,'']]],
  ['logger_2eh',['logger.h',['../logger_8h.html',1,'']]],
  ['logger_5foff',['logger_off',['../logger_8c.html#a53b1a92a2e247cbe69f3228f1ca843ff',1,'logger_off():&#160;logger.c'],['../logger_8h.html#a53b1a92a2e247cbe69f3228f1ca843ff',1,'logger_off():&#160;logger.c']]],
  ['logger_5fon',['logger_on',['../logger_8c.html#ab19a775288f6112bcf8ca37b8975eabc',1,'logger_on():&#160;logger.c'],['../logger_8h.html#ab19a775288f6112bcf8ca37b8975eabc',1,'logger_on():&#160;logger.c']]],
  ['logger_5fread',['logger_read',['../logger_8c.html#a780e797c271a45b2c9c001a1d553855f',1,'logger_read():&#160;logger.c'],['../logger_8h.html#a780e797c271a45b2c9c001a1d553855f',1,'logger_read():&#160;logger.c']]]
];
