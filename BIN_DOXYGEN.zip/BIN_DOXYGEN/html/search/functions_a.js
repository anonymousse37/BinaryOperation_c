var searchData=
[
  ['time_5fadd',['time_add',['../tim_8c.html#a03851815f11b0d9b8a29e1448cbc2f07',1,'time_add(t_time *t1, t_time *t2):&#160;tim.c'],['../tim_8h.html#a03851815f11b0d9b8a29e1448cbc2f07',1,'time_add(t_time *t1, t_time *t2):&#160;tim.c']]],
  ['time_5fclock_5fstart',['time_clock_start',['../tim_8c.html#ada57e01fc348cceefaaf6f227849091d',1,'tim.c']]],
  ['time_5fclock_5fstop',['time_clock_stop',['../tim_8c.html#a4962edd04a5c8edc592b30cbdb3a1a1f',1,'tim.c']]],
  ['time_5fcreate_5fstructure',['time_create_structure',['../tim_8c.html#a5fe663f17b49cc5783ae5f6a5fa7c936',1,'time_create_structure():&#160;tim.c'],['../tim_8h.html#a5fe663f17b49cc5783ae5f6a5fa7c936',1,'time_create_structure():&#160;tim.c']]],
  ['time_5fdestroy_5fstructure',['time_destroy_structure',['../tim_8c.html#a6827c4db2c3278027664b8c0c791cfc2',1,'time_destroy_structure(t_time *t):&#160;tim.c'],['../tim_8h.html#a942135a6df7bb641ef46defc8c4ba65d',1,'time_destroy_structure():&#160;tim.h']]],
  ['time_5fdisplay',['time_display',['../tim_8c.html#a43d857c88ce511721fac185fa25c41ba',1,'time_display(t_time *t):&#160;tim.c'],['../tim_8h.html#a43d857c88ce511721fac185fa25c41ba',1,'time_display(t_time *t):&#160;tim.c']]],
  ['time_5fformat',['time_format',['../tim_8c.html#a3de4e727d446c024708e7958456b4c83',1,'time_format(double x, t_time *t):&#160;tim.c'],['../tim_8h.html#a3de4e727d446c024708e7958456b4c83',1,'time_format(double x, t_time *t):&#160;tim.c']]],
  ['time_5fsecond',['time_second',['../tim_8c.html#ab0adf70d35837fb33d4ca24ff4a0c0ef',1,'time_second(t_time *t):&#160;tim.c'],['../tim_8h.html#ab0adf70d35837fb33d4ca24ff4a0c0ef',1,'time_second(t_time *t):&#160;tim.c']]],
  ['time_5fsub',['time_sub',['../tim_8c.html#a71b8d0d4619f29e7c16c5832c8200326',1,'time_sub(t_time *t1, t_time *t2):&#160;tim.c'],['../tim_8h.html#a71b8d0d4619f29e7c16c5832c8200326',1,'time_sub(t_time *t1, t_time *t2):&#160;tim.c']]],
  ['time_5fwait',['time_wait',['../tim_8c.html#ae11cce89483b35e1bef3f86a982cff0b',1,'time_wait(double x):&#160;tim.c'],['../tim_8h.html#ae11cce89483b35e1bef3f86a982cff0b',1,'time_wait(double x):&#160;tim.c']]]
];
